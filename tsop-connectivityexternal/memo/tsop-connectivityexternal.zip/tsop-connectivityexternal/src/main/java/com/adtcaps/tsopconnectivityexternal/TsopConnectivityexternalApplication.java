package com.adtcaps.tsopconnectivityexternal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TsopConnectivityexternalApplication {

	public static void main(String[] args) {
		SpringApplication.run(TsopConnectivityexternalApplication.class, args);
	}

}
