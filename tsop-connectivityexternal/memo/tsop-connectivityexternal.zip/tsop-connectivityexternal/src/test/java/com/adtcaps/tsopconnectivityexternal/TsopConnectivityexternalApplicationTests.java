package com.adtcaps.tsopconnectivityexternal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TsopConnectivityexternalApplicationTests {

	@Test
	void contextLoads() {
	}

}
